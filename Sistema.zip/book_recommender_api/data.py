# Estruturas em memória
users = {}   # user_id -> {"nome":..., "genero_preferido":...}
books = {}   # book_id -> {"titulo":..., "autores":..., "generos":...}
ratings = [] # lista de dicts {"user_id":..., "book_id":..., "nota":...}
