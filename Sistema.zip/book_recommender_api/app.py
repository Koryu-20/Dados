# app.py.
from flask import Flask, request, jsonify
from books_service import load_books
from data import users, books, ratings
from model import recommend_books

app = Flask(__name__)

# Carrega livros ao iniciar a aplicação se a lista estiver vazia.
if not books:
    load_books()

# Divide os livros em dois grupos.
# Os primeiros 30 livros para o usuário avaliar.
books_to_evaluate = list(books.values())[:30]
# Os 20 livros restantes serão usados para a recomendação.
books_for_recommendation = list(books.values())[30:]

# 1. Cadastro de usuário.
@app.route("/register", methods=["POST"])
def register():
    data = request.json
    nome = data["nome"].strip()
    genero = data["genero_preferido"].strip()

    for uid, u in users.items():
        if u["nome"].lower() == nome.lower():
            return jsonify({"message": "Usuário já cadastrado", "user_id": uid}), 200

    user_id = str(len(users) + 1)
    users[user_id] = {"nome": nome, "genero_preferido": genero}
    return jsonify({"message": "Usuário criado", "user_id": user_id}), 200

# 2. Listar livros para avaliação.
# Agora retorna apenas os primeiros 30 livros.
@app.route("/books/<user_id>", methods=["GET"])
def list_books_for_user(user_id):
    # Retorna a mesma lista de livros que /books — mantido para compatibilidade com a interface Streamlit.
    return jsonify(list(books_to_evaluate)), 200

# 3. Avaliar livro.
@app.route("/rate", methods=["POST"])
def rate_book():
    data = request.json
    user_id, book_id, nota = data["user_id"], data["book_id"], data["nota"]

    # Verifica se a avaliação já existe para o usuário e livro.
    for r in ratings:
        if r["user_id"] == user_id and r["book_id"] == book_id:
            r["nota"] = nota
            return jsonify({"message": "Avaliação atualizada com sucesso!"}), 200

    ratings.append({"user_id": user_id, "book_id": book_id, "nota": nota})
    return jsonify({"message": "Avaliação registrada com sucesso!"}), 200

# 4. Recomendação.
# Agora usa a nova lista de livros para a recomendação.
@app.route("/recommend/<user_id>", methods=["GET"])
def recommend(user_id):
    recs = recommend_books(user_id, books_for_recommendation)
    if recs:
        return jsonify(recs), 200
    return jsonify({"mensagem": "Sem recomendações no momento. Avalie mais livros ou tente novamente."}), 200

# 5. Listar avaliações de um usuário específico.
@app.route("/user-ratings/<user_id>", methods=["GET"])
def user_ratings(user_id):
    user_rated_books = [r for r in ratings if r["user_id"] == user_id]
    if not user_rated_books:
        return jsonify({"mensagem": "Este usuário ainda não avaliou nenhum livro."}), 200

    detalhes = []
    for r in user_rated_books:
        book = books.get(r["book_id"], {})
        detalhes.append({
            "titulo": book.get("titulo", "Sem título"),
            "nota": r["nota"]
        })
    return jsonify(detalhes), 200

if __name__ == "__main__":
    app.run(debug=True)

