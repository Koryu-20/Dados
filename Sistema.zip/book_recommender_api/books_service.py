import requests
from data import books

def load_books():
    subjects = ["romance", "fantasy", "fiction", "history", "science"]
    base_url = "https://www.googleapis.com/books/v1/volumes?q=subject:{}&maxResults=10"

    for subject in subjects:
        response = requests.get(base_url.format(subject))
        if response.status_code == 200:
            items = response.json().get("items", [])
            for item in items:
                book_id = item["id"]
                volume_info = item.get("volumeInfo", {})
                books[book_id] = {
                    "book_id": book_id,
                    "titulo": volume_info.get("title", "Sem título"),
                    "autores": volume_info.get("authors", []),
                    "generos": volume_info.get("categories", [])
                }
