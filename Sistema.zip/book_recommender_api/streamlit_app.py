import streamlit as st
import requests

# URL da API local
API_URL = "http://127.0.0.1:5000"

st.set_page_config(page_title="Book Recommender", page_icon="📚", layout="wide")

# Estilos CSS
st.markdown("""
<style>
.big-font { font-size:30px !important; font-weight:bold; }
.medium-font { font-size:20px !important; font-weight:bold; }
.small-font { font-size:16px; }
</style>
""", unsafe_allow_html=True)

st.markdown('<p class="big-font">📚 Recomendador de Livros</p>', unsafe_allow_html=True)

# Sidebar - Cadastro
st.sidebar.markdown('<p class="medium-font">👤 Cadastro de Usuário</p>', unsafe_allow_html=True)
nome = st.sidebar.text_input("Nome")
genero = st.sidebar.text_input("Gênero Preferido (ex: Romance, Comédia, Ficção, etc...)")
if st.sidebar.button("Cadastrar"):
    if nome and genero:
        try:
            resp = requests.post(f"{API_URL}/register", json={"nome": nome, "genero_preferido": genero})
            if resp.status_code == 200:
                data = resp.json()
                st.sidebar.success(f"{data['message']} - ID: {data['user_id']}")
            else:
                st.sidebar.error("Erro ao cadastrar usuário")
        except requests.exceptions.ConnectionError:
            st.sidebar.error("Não foi possível conectar à API. Verifique se o servidor está rodando.")
    else:
        st.sidebar.warning("Preencha nome e gênero!")

user_id = st.sidebar.text_input("Informe seu User ID")

# Inicializa o estado da sessão
if "livros" not in st.session_state:
    st.session_state["livros"] = None
if "recomendacoes" not in st.session_state:
    st.session_state["recomendacoes"] = None

# Função para exibir um livro e a opção de avaliação
def exibir_livro(livro, user_id):
    with st.expander(livro["titulo"]):
        st.write("Autores:", ", ".join(livro.get("autores", [])))
        st.write("Gêneros:", ", ".join(livro.get("generos", [])))

        if user_id:
            # Garante que a chave do slider e do botão são únicas para cada livro e usuário
            slider_key = f"nota_slider_{user_id}_{livro['book_id']}"
            button_key = f"salvar_button_{user_id}_{livro['book_id']}"
            
            if slider_key not in st.session_state:
                st.session_state[slider_key] = 1

            st.slider(f"Avaliar {livro['titulo']}", 1, 5, key=slider_key)
            nota = st.session_state[slider_key]

            if st.button("Salvar Avaliação", key=button_key):
                try:
                    rate_resp = requests.post(f"{API_URL}/rate", json={
                        "user_id": user_id,
                        "book_id": livro["book_id"],
                        "nota": int(nota)
                    })
                    if rate_resp.status_code == 200:
                        st.success(rate_resp.json().get("message", "Avaliação registrada!"))
                        # Limpa recomendações antigas para que o usuário precise clicar novamente
                        st.session_state["recomendacoes"] = None
                    else:
                        st.error("Erro ao registrar avaliação")
                except requests.exceptions.ConnectionError:
                    st.error("Não foi possível conectar à API. Verifique se o servidor está rodando.")

# Carregar e exibir a lista de livros
st.markdown('<p class="medium-font">📖 Lista de Livros para Avaliação</p>', unsafe_allow_html=True)
if st.button("Carregar Livros"):
    if not user_id:
        st.error("Informe seu User ID antes de carregar livros")
    else:
        try:
            resp = requests.get(f"{API_URL}/books/{user_id}")
            if resp.status_code == 200:
                st.session_state["livros"] = resp.json()
            else:
                st.error("Erro ao carregar livros")
        except requests.exceptions.ConnectionError:
            st.error("Não foi possível conectar à API. Verifique se o servidor está rodando.")

# Exibe livros carregados
if st.session_state["livros"]:
    for livro in st.session_state["livros"]:
        exibir_livro(livro, user_id)

# Botão para gerar recomendações
if st.button("Gerar Recomendações"):
    if not user_id:
        st.error("Informe seu User ID antes de gerar recomendações")
    else:
        try:
            rec_resp = requests.get(f"{API_URL}/recommend/{user_id}")
            # Verifica o status da resposta antes de tentar processar o JSON
            if rec_resp.status_code == 200:
                rec_data = rec_resp.json()
                # Verifica se a resposta contém a lista de recomendações
                if "recomendados" in rec_data:
                    st.session_state["recomendacoes"] = rec_data
                else:
                    # Se não houver recomendações, limpa o estado e mostra um aviso
                    st.session_state["recomendacoes"] = None
                    st.warning(rec_data.get("mensagem", "Nenhuma recomendação disponível ainda."))
            else:
                st.error("Erro ao gerar recomendações")
        except requests.exceptions.ConnectionError:
            st.error("Não foi possível conectar à API. Verifique se o servidor está rodando.")

# Exibe recomendações
if st.session_state["recomendacoes"]:
    st.markdown('<p class="medium-font">🌟 Recomendações para você</p>', unsafe_allow_html=True)
    rec_data = st.session_state["recomendacoes"]
    if rec_data and "recomendados" in rec_data:
        # A mensagem do JSON da API é usada para o sucesso
        st.success(rec_data.get("mensagem", "Recomendações geradas com sucesso!"))
        # Itera sobre a lista de livros recomendados
        for livro in rec_data["recomendados"]:
            st.write(f"📌 {livro.get('titulo', 'Sem título')} ({', '.join(livro.get('autores', []))})")
            st.write("Gêneros:", ", ".join(livro.get("generos", [])))
            st.write("Nota prevista:", livro.get("nota_prevista", "N/A"))
            st.write("---")
