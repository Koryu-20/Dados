import streamlit as st
import requests

# URL da API local.
API_URL = "http://127.0.0.1:5000"

st.set_page_config(page_title="Book Recommender", page_icon="📚", layout="wide")

# Estilos CSS.
st.markdown("""
<style>
.big-font { font-size:30px !important; font-weight:bold; }
.medium-font { font-size:20px !important; font-weight:bold; }
.small-font { font-size:16px; }
</style>
""", unsafe_allow_html=True)

st.markdown('<p class="big-font">📚 Recomendador de Livros</p>', unsafe_allow_html=True)

# Inicializa o estado da sessão.
if "livros" not in st.session_state:
    st.session_state["livros"] = []
if "recomendacoes" not in st.session_state:
    st.session_state["recomendacoes"] = None
if "user_id" not in st.session_state:
    st.session_state["user_id"] = ""

def exibir_livro(livro, user_id):
    st.subheader(livro.get("titulo", "Sem título"))
    autores_str = ", ".join(livro.get("autores", ["Autor(es) Desconhecido(s)"]))
    generos_str = ", ".join(livro.get("generos", ["Gênero(s) Desconhecido(s)"]))
    st.write(f"**Autor(es):** {autores_str}")
    st.write(f"**Gêneros:** {generos_str}")
    
    # Adiciona um controle de avaliação se um user_id estiver presente.
    if user_id:
        nota = st.slider(
            "Sua nota", 
            min_value=1.0, 
            max_value=5.0, 
            step=0.5, 
            key=f"slider_{livro['book_id']}"
        )
        if st.button("Avaliar", key=f"btn_rate_{livro['book_id']}"):
            try:
                rate_resp = requests.post(
                    f"{API_URL}/rate", 
                    json={
                        "user_id": user_id, 
                        "book_id": livro["book_id"], 
                        "nota": nota
                    }
                )
                if rate_resp.status_code == 200:
                    st.success(f"Avaliação de {nota} registrada para o livro {livro['titulo']}.")
                else:
                    st.error("Erro ao registrar avaliação.")
            except requests.exceptions.ConnectionError:
                st.error("Não foi possível conectar à API. Verifique se o servidor está rodando.")

# Sidebar - Cadastro.
st.sidebar.markdown('<p class="medium-font">👤 Cadastro de Usuário</p>', unsafe_allow_html=True)
nome = st.sidebar.text_input("Nome")
genero = st.sidebar.text_input("Gênero Preferido (ex: Romance, Ficção, etc...)")
if st.sidebar.button("Cadastrar"):
    if nome and genero:
        try:
            resp = requests.post(f"{API_URL}/register", json={"nome": nome, "genero_preferido": genero})
            if resp.status_code == 200:
                data = resp.json()
                st.session_state["user_id"] = data["user_id"]
                st.sidebar.success(f"{data['message']} - ID: {data['user_id']}")
            else:
                st.sidebar.error("Erro ao cadastrar usuário.")
        except requests.exceptions.ConnectionError:
            st.sidebar.error("Não foi possível conectar à API.")

# Sidebar - Login e Avaliação.
st.sidebar.markdown('<p class="medium-font">🔎 Login e Avaliação</p>', unsafe_allow_html=True)
user_id_input = st.sidebar.text_input("Seu ID de Usuário", value=st.session_state["user_id"])
if user_id_input:
    st.session_state["user_id"] = user_id_input

if st.sidebar.button("Listar Livros para Avaliar"):
    try:
        resp = requests.get(f"{API_URL}/books/{st.session_state['user_id']}")
        if resp.status_code == 200:
            st.session_state["livros"] = resp.json()
        else:
            st.error("Erro ao carregar livros.")
    except requests.exceptions.ConnectionError:
        st.error("Não foi possível conectar à API.")

# Exibe os livros para avaliação.
if st.session_state["livros"]:
    st.markdown('<p class="medium-font">📚 Avalie os Livros</p>', unsafe_allow_html=True)
    for livro in st.session_state["livros"]:
        exibir_livro(livro, st.session_state["user_id"])

# Recomendação.
if st.button("Gerar Recomendações"):
    if not st.session_state["user_id"]:
        st.error("Informe seu ID de Usuário antes de gerar recomendações.")
    else:
        try:
            rec_resp = requests.get(f"{API_URL}/recommend/{st.session_state['user_id']}")
            if rec_resp.status_code == 200:
                rec_data = rec_resp.json()
                # Verifica se a resposta contém a lista de recomendações.
                if "recomendados" in rec_data:
                    st.session_state["recomendacoes"] = rec_data
                else:
                    # Se não houver recomendações, limpa o estado e mostra um aviso.
                    st.session_state["recomendacoes"] = None
                    st.warning(rec_data.get("mensagem", "Nenhuma recomendação disponível ainda."))
            else:
                st.error("Erro ao gerar recomendações.")
        except requests.exceptions.ConnectionError:
            st.error("Não foi possível conectar à API. Verifique se o servidor está rodando.")

# Exibe recomendações.
if st.session_state["recomendacoes"]:
    st.markdown('<p class="medium-font">🌟 Recomendações para você</p>', unsafe_allow_html=True)
    rec_data = st.session_state["recomendacoes"]
    if rec_data and "recomendados" in rec_data:
        # A mensagem do JSON da API é usada para o sucesso.
        st.success(rec_data.get("mensagem", "Recomendações geradas com sucesso!"))
        # Itera sobre a lista de livros recomendados.
        for livro in rec_data["recomendados"]:
            st.write(f"📌 {livro.get('titulo', 'Sem título')} ({', '.join(livro.get('autores', []))})")
            st.write("Gêneros:", ", ".join(livro.get("generos", [])))
            # Exibe o motivo da recomendação se estiver presente.
            st.info(livro.get("motivo", ""))

# Exibe avaliações do usuário.
if st.button("Ver minhas avaliações"):
    if not st.session_state["user_id"]:
        st.error("Informe seu ID de Usuário para ver suas avaliações.")
    else:
        try:
            my_ratings_resp = requests.get(f"{API_URL}/user-ratings/{st.session_state['user_id']}")
            if my_ratings_resp.status_code == 200:
                ratings_data = my_ratings_resp.json()
                st.markdown('<p class="medium-font">📖 Suas Avaliações</p>', unsafe_allow_html=True)
                if "mensagem" in ratings_data:
                    st.info(ratings_data["mensagem"])
                else:
                    for r in ratings_data:
                        st.write(f"**{r['titulo']}** - Nota: **{r['nota']}**")
            else:
                st.error("Erro ao carregar suas avaliações.")
        except requests.exceptions.ConnectionError:
            st.error("Não foi possível conectar à API. Verifique se o servidor está rodando.")

