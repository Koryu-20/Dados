import numpy as np
from sklearn.neighbors import KNeighborsRegressor
from data import ratings, books, users

def _build_genre_index():
    """Retorna um mapeamento de gênero -> índice (lowercased)."""
    genres = set()
    for b in books.values():
        for g in b.get("generos", []) or []:
            genres.add(g.lower())
    genres = sorted(genres)
    return {g: i for i, g in enumerate(genres)}

def _book_features(book, genre_to_idx):
    """Converte os gêneros do livro num vetor multi-hot."""
    vec = np.zeros(len(genre_to_idx), dtype=float)
    for g in (book.get("generos") or []):
        gi = genre_to_idx.get(g.lower())
        if gi is not None:
            vec[gi] = 1.0
    return vec

def _average_ratings():
    """Calcula média de notas por book_id a partir das avaliações existentes."""
    sums = {}
    counts = {}
    for r in ratings:
        bid = r["book_id"]
        sums[bid] = sums.get(bid, 0) + float(r["nota"])
        counts[bid] = counts.get(bid, 0) + 1
    avg = {}
    for bid, s in sums.items():
        avg[bid] = s / counts[bid]
    return avg

def recommend_books(user_id, books_for_recommendation, top_n=5):
    """
    Recomenda livros para um usuário específico.
    
    A função agora recebe 'books_for_recommendation' para buscar os livros candidatos.
    """
    user_ratings = [r for r in ratings if r["user_id"] == user_id]
    
    # Lógica de fallback para quando o usuário não tem avaliações suficientes
    if len(user_ratings) < 3:
        # Recomendação baseada no gênero preferido do usuário
        user = users.get(user_id)
        if not user or not user.get("genero_preferido"):
            return {"mensagem": "Não foi possível gerar recomendações. Avalie mais livros ou cadastre um gênero preferido."}

        # Busca livros da lista de recomendação que correspondem ao gênero
        recs = [b for b in books_for_recommendation if user["genero_preferido"].lower() in [g.lower() for g in b.get("generos", [])]]
        
        # Se não encontrar nada, retorna os 5 primeiros livros da lista de recomendação
        if not recs:
            recs = books_for_recommendation[:5]

        # Formata a resposta
        recs_data = [
            {"book_id": b["book_id"], "titulo": b["titulo"], "autores": b["autores"], "generos": b["generos"], "nota_prevista": "N/A"}
            for b in recs[:top_n]
        ]
        return {"mensagem": f"Você ainda não avaliou livros suficientes. Aqui estão recomendações baseadas no seu gênero preferido: {user['genero_preferido']}.", "recomendados": recs_data}

    # Lógica de recomendação baseada em ML
    genre_to_idx = _build_genre_index()
    
    X = []
    y = []
    for r in user_ratings:
        feat = _book_features(books.get(r["book_id"], {}), genre_to_idx)
        X.append(feat)
        y.append(float(r["nota"]))

    X = np.vstack(X)
    y = np.array(y, dtype=float)

    n_neighbors = min(5, len(X))
    if n_neighbors < 1:
        n_neighbors = 1

    model = KNeighborsRegressor(n_neighbors=n_neighbors, weights='distance')
    model.fit(X, y)

    # Prever para livros que o usuário NÃO avaliou, usando a nova lista de candidatos
    rated_by_user = {r["book_id"] for r in user_ratings}
    candidates = []
    for book in books_for_recommendation:
        book_id = book["book_id"]
        if book_id in rated_by_user:
            continue
        try:
            feat = _book_features(book, genre_to_idx)
            pred = model.predict(feat.reshape(1, -1))[0]
            pred = float(np.clip(pred, 1.0, 5.0))
            candidates.append((book_id, pred))
        except Exception:
            continue
    
    if not candidates:
        return {"mensagem": "Todos os livros disponíveis para recomendação já foram avaliados por você."}

    candidates.sort(key=lambda x: x[1], reverse=True)
    top = candidates[:top_n]

    recs = []
    for bid, score in top:
        b = books.get(bid, {})
        recs.append({
            "book_id": bid,
            "titulo": b.get("titulo", "Sem título"),
            "autores": b.get("autores", []),
            "generos": b.get("generos", []),
            "nota_prevista": float(f"{score:.2f}")
        })

    return {"mensagem": "Recomendações geradas com sucesso!", "recomendados": recs}
