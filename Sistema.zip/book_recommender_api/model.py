import numpy as np
from sklearn.neighbors import KNeighborsRegressor
from data import ratings, books, users
import random

def _build_genre_index():
    """Retorna um mapeamento de gênero -> índice (lowercased)."""
    genres = set()
    for b in books.values():
        for g in b.get("generos", []) or []:
            genres.add(g.lower())
    genres = sorted(genres)
    return {g: i for i, g in enumerate(genres)}

def _book_features(book, genre_to_idx):
    """Converte os gêneros do livro num vetor multi-hot."""
    vec = np.zeros(len(genre_to_idx), dtype=float)
    for g in (book.get("generos") or []):
        gi = genre_to_idx.get(g.lower())
        if gi is not None:
            vec[gi] = 1.0
    return vec

def recommend_books(user_id, books_for_recommendation, top_n=5):
    # Obtém as avaliações do usuário atual.
    user_ratings = [r for r in ratings if r["user_id"] == user_id]
    user_data = users.get(user_id)
    
    # Se o usuário não avaliou pelo menos 3 livros, recomenda com base no gênero preferido.
    if len(user_ratings) < 3:
        if not user_data or not user_data.get("genero_preferido"):
            return None
        
        prefered_genre = user_data["genero_preferido"].lower()
        
        # Encontra livros do gênero preferido que o usuário ainda não avaliou.
        unrated_books = [
            b for b in books_for_recommendation 
            if b.get("book_id") not in {r["book_id"] for r in user_ratings} and 
            any(g.lower() == prefered_genre for g in b.get("generos", []))
        ]
        
        if not unrated_books:
            return {"mensagem": f"Não há livros de {prefered_genre.capitalize()} disponíveis para recomendação."}
            
        random.shuffle(unrated_books)
        recs = unrated_books[:top_n]
        
        recs_data = []
        for b in recs:
            recs_data.append({
                "book_id": b.get("book_id"),
                "titulo": b.get("titulo"),
                "autores": b.get("autores"),
                "generos": b.get("generos"),
                "motivo": f"Recomendado com base no seu gênero preferido: {prefered_genre.capitalize()}."
            })
        
        return {"mensagem": f"Você precisa avaliar pelo menos 3 livros para receber recomendações personalizadas. Aqui estão algumas sugestões de {prefered_genre.capitalize()}.", "recomendados": recs_data}

    # Se o usuário avaliou 3 ou mais livros, usa o modelo de ML.
    genre_to_idx = _build_genre_index()
    
    X, y = [], []
    for r in user_ratings:
        feat = _book_features(books.get(r["book_id"]), genre_to_idx)
        X.append(feat)
        y.append(float(r["nota"]))

    X = np.vstack(X)
    y = np.array(y, dtype=float)

    n_neighbors = min(5, len(X))
    if n_neighbors < 1:
        n_neighbors = 1

    # Treinar KNeighborsRegressor.
    model = KNeighborsRegressor(n_neighbors=n_neighbors, weights='distance')
    model.fit(X, y)

    # Prever para livros que o usuário NÃO avaliou, usando a nova lista de candidatos.
    rated_by_user = {r["book_id"] for r in user_ratings}
    candidates = []
    for book in books_for_recommendation:
        book_id = book["book_id"]
        if book_id in rated_by_user:
            continue
        try:
            feat = _book_features(book, genre_to_idx)
            pred = model.predict(feat.reshape(1, -1))[0]
            # garantir intervalo 1-5.
            pred = float(np.clip(pred, 1.0, 5.0))
            candidates.append((book_id, pred))
        except Exception:
            continue
    
    if not candidates:
        return {"mensagem": "Todos os livros disponíveis para recomendação já foram avaliados por você."}

    # Ordenar por nota prevista desc.
    candidates.sort(key=lambda x: x[1], reverse=True)
    top = candidates[:top_n]

    recs = []
    for bid, score in top:
        b = books.get(bid, {})
        recs.append({
            "book_id": b.get("book_id"),
            "titulo": b.get("titulo"),
            "autores": b.get("autores"),
            "generos": b.get("generos"),
            "motivo": f"Recomendado com base na sua avaliação de outros livros. Nota prevista: {score:.2f}."
        })
    
    return {"mensagem": "Recomendações personalizadas geradas com sucesso.", "recomendados": recs}
